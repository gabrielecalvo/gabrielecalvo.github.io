import streamlit as st

def main():
    st.sidebar.markdown("""
        # Navigation
        this is where navigation stuff should go
    """)

    st.markdown("""
    # My Title
    
    This is where the content should go
    """)

if __name__ == "__main__":
    main()
